# path: marker-engine/SKILL.md
---
name: marker-engine
description: Ermöglicht Agenten, LD‑3.5‑kompatible Marker (ATO/SEM/CLU/MEMA, inkl. CLU_INTUITION und RF2.0‑Kontext) aus einer Superbase/DB zu beziehen und in Echtzeit auf Textströme anzuwenden; liefert strukturierte Treffer, Zustände, Scoring und Telemetrie.
---

## Wann verwenden
Verwenden, wenn:
- Textströme (Chats, E‑Mails, Tickets, Protokolle) in Echtzeit oder batchweise entlang der LD‑3.5‑Markerhierarchie analysiert werden sollen. 
- Marker aus einer Datenbank („Superbase“) oder einem API‑Endpunkt geladen und live angewendet werden müssen.
- Intuitions‑Marker (zustandsbehaftete CLUs) und RF‑Kontext (Resonance Framework 2.0) die Interpretation schärfen sollen. 

## Architektur & Regeln (Kurzüberblick)
- **Vier‑Ebenen‑Architektur**: ATO (pattern) → SEM (composed_of, ≥2 ATOs) → CLU (composed_of + activation X‑of‑Y) → MEMA (composed_of oder detect_class). 
- **Universelle Schema‑Pflichten**: `frame{signal,concept,pragmatics,narrative}`, `examples[≥5]`, **genau ein** Strukturblock (`pattern` | `composed_of` | `detect_class`). 
- **SEM‑Komposition**: ≥2 **unterschiedliche** ATOs, CI‑Check „sem‑composition‑check“, Ausnahmen nur mit `justification`. 
- **Intuitions‑Marker (CLU_INTUITION_*)**: Zustände *provisional → confirmed → decayed*, `multiplier_on_confirm`, Telemetrie `ewma_precision` steuert Regel‑Adaption. 
- **RF2.0 / RF_BRIDGE**: Kontextualisiert Verhalten über Entwicklungsstufen (z. B. L1‑STONE vs. L6‑WATER); gleiche Hierarchie (ATO/SEM/CLU) bleibt erhalten. 

## Eingaben
- **text**: String, Array von Strings oder Stream.
- **markers_source**:
  - `type`: `superbase` | `http` | `local`.
  - `config` (Beispiel): `{ base_url, api_key, collection="markers", version="3.5" }`.
- **runtime**:
  - `chunk_size` (Zeichen), `stride` (Overlap). (Verhindert CLU‑Zerfall an Chunk‑Kanten.) 
  - `sem_temperature` (Empfindlichkeit für SEM‑Erkennung). 
  - `clu_window`: X‑of‑Y Regel‑Fenster pro Stream. 
  - `gates`: `{ min_total_markers, min_segments }` (Blockt unzuverlässige Runs: `E_GATE_BLOCKED`). 
  - `families_filter`: z. B. `["CONFLICT","SUPPORT","UNCERTAINTY"]`.

## Workflow/Anweisungen
1) **Marker laden & validieren**  
   Lade Registry (Superbase/API/local). Prüfe: gültiges Präfix (ATO_/SEM_/CLU_/MEMA_), `frame` vollständig, `examples≥5`, genau ein Strukturblock. Nicht‑konforme Marker verwerfen. 

2) **Text ingestieren**  
   Segmentiere Text in Chunks mit `chunk_size` und `stride`. Erfasse Segment‑IDs und Offsets. 

3) **ATO erkennen (Level 1)**  
   Wende `pattern` (Tokenlisten/Regex) an und emittiere ATO‑Treffer (mit Offsets). Beispiele: `ATO_HESITATION`, `ATO_DOUBT_PHRASE`. 

4) **SEM komponieren (Level 2)**  
   Verknüpfe ATOs gemäß SEM‑`composed_of` und Aktivierungsregel (z. B. „BOTH IN 1 message“ oder „ANY 2 IN 2 messages“). Durchsetze die Regel **≥2 unterschiedliche ATOs**. 

5) **CLU aggregieren (Level 3)**  
   Aggregiere thematisch verwandte SEMs innerhalb eines Fensters per `activation.rule` (typisch „AT_LEAST X IN Y messages“). Beispiel: `CLU_CONFLICT_ESCALATION`. 

6) **MEMA analysieren (Level 4)**  
   Führe Meta‑Analysen über mehrere CLUs aus (via `composed_of` oder `detect_class`) und emittiere Trends/Verläufe (z. B. `MEMA_RELATIONAL_INSTABILITY`). 

7) **Intuition (zustandsbehaftet)**  
   Für `CLU_INTUITION_*` berechne Zustandswechsel:  
   - *provisional*: Vorfenster erfüllt (z. B. „AT_LEAST 2 DISTINCT SEMs IN 5 messages“).  
   - *confirmed*: „hartes“ SEM innerhalb `confirm_window` → aktiviere `multiplier_on_confirm` für Familien‑Marker (TTL=confirm_window).  
   - *decayed*: Keine Familien‑SEMs innerhalb `decay_window` → `retracted++`.  
   Aktualisiere `ewma_precision` und passe Regeln (loosen/tighten) datengestützt an. 

8) **RF‑Kontext anwenden (RF_BRIDGE)**  
   Kombiniere aktive RF‑Level‑Marker (z. B. `CLU_LEVEL_L1_STONE`) mit Verhaltensmarkern (z. B. `EMOTIONAL_WITHDRAW.SEM_*`) zu Manifestationen; Bedeutung variiert je Level. 

9) **Gates & Bias‑Schutz**  
   Erzwinge `gates`. Bei Fall emit `E_GATE_BLOCKED`. DISTINCT‑Anforderung im Vorfenster reduziert Bestätigungsfehler. 

## Ausgabeformat
Gib **ein JSON‑Objekt** zurück:

```json
{
  "events":[
    {
      "id":"ATO_HESITATION",
      "level":"ATO",
      "span":{"seg":12,"from":4,"to":7},
      "text":"Ähm",
      "score":1.0,
      "frame":{"signal":["token"],"concept":"Zögern","pragmatics":"Hedging","narrative":"stall"},
      "source":"pattern"
    },
    {
      "id":"SEM_UNCERTAINTY_TONING",
      "level":"SEM",
      "components":["ATO_HESITATION","ATO_DOUBT_PHRASE"],
      "activation":"BOTH IN 1 message",
      "score":0.82
    },
    {
      "id":"CLU_CONFLICT_ESCALATION",
      "level":"CLU",
      "components":["SEM_NEGATIVE_FEEDBACK","SEM_ESCALATION_MOVE"],
      "activation":"AT_LEAST 2 DISTINCT SEMs IN 4 messages",
      "score":0.74
    }
  ],
  "intuition":[
    {
      "id":"CLU_INTUITION_CONFLICT",
      "state":"provisional",
      "confirm_window":4,
      "decay_window":6,
      "ewma_precision":0.64,
      "multiplier_active":false
    }
  ],
  "rf_context":{"level":"L6-WATER","intensity":0.55},
  "gates":{"min_total_markers":3,"min_segments":2,"passed":true},
  "telemetry":{"segments":5,"tokens":374}