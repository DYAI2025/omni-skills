import re, sys, os, zipfile

RE_NAME = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')

RE_FRONT = re.compile(r'^---\s*$')
HEADINGS = [
    "## Wann verwenden",
    "## Workflow/Anweisungen",
    "## Ausgabeformat",
    "## Beispiele",
]

def parse_frontmatter(md_text:str):
    lines = md_text.splitlines()
    if not lines or not RE_FRONT.match(lines[0]):
        return {}
    i = 1
    front = []
    while i < len(lines) and not RE_FRONT.match(lines[i]):
        front.append(lines[i])
        i += 1
    fm = {}
    for ln in front:
        if ":" in ln:
            k, v = ln.split(":", 1)
            fm[k.strip()] = v.strip().strip('"').strip("'")
    return fm

def main():
    if len(sys.argv) != 2:
        print("Usage: python quick_validate.py <pfad/zum/skill-ordner>", file=sys.stderr)
        sys.exit(2)
    root = sys.argv[1]
    path = os.path.join(root, "SKILL.md")
    if not os.path.isfile(path):
        print("FAIL: SKILL.md nicht gefunden")
        sys.exit(1)
    txt = open(path, "r", encoding="utf-8").read()
    fm = parse_frontmatter(txt)
    ok = True

    name = fm.get("name","")
    desc = fm.get("description","")

    if not RE_NAME.fullmatch(name or ""):
        print(f"FAIL: name ungültig: {name!r}")
        ok = False
    if not desc or "<" in desc or ">" in desc:
        print("FAIL: description fehlt oder enthält spitze Klammern (< >)")
        ok = False

    for h in HEADINGS:
        if h not in txt:
            print(f"FAIL: Abschnitt fehlt: {h}")
            ok = False

    if ok:
        print("OK: Frontmatter & Grundstruktur valide")
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()
