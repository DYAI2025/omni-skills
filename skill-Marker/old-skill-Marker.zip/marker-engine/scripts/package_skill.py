import os, sys, zipfile, time

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            rp = os.path.relpath(fp, os.path.dirname(path))
            ziph.write(fp, rp)

def main():
    if len(sys.argv) < 2:
        print("Usage: python package_skill.py <pfad/zum/skill-ordner> [distdir]")
        sys.exit(2)
    skill = sys.argv[1]
    dist = sys.argv[2] if len(sys.argv) >= 3 else os.path.join(os.path.dirname(skill), "dist")
    os.makedirs(dist, exist_ok=True)
    out = os.path.join(dist, f"{os.path.basename(skill.rstrip(os.sep))}.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        zipdir(skill, z)
    print(out)

if __name__ == "__main__":
    main()
