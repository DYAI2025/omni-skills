# Resonance Framework 2.0 (RF2.0) & RF_BRIDGE – Kurzleitfaden

**Prinzip**: „Die Stufe färbt den Marker.“
RF‑Detektoren (z. B. CLU_LEVEL_L1_STONE, CLU_LEVEL_L6_WATER) werden wie reguläre ATO/SEM/CLU definiert und bleiben schema‑konform. Die **RF_BRIDGE** kombiniert aktive RF‑Level mit Verhaltensmarkern zu **Manifestationen** (z. B. EMOTIONAL_WITHDRAW × L6‑WATER → verletzter Rückzug).

**Beispielmatrix (ausgeführt):**

- L1‑STONE × EMOTIONAL_WITHDRAW → physisches Erstarren/Verstecken.
- L6‑WATER × EMOTIONAL_WITHDRAW → verletzter Rückzug (Überwältigung).
