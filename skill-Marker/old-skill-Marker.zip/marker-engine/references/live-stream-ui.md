# Live‑Stream & Panel‑Anbindung

## Stream‑Pipeline

- **Chunk/Stride**: Stride‑Overlap verhindert, dass CLU‑Sequenzen an Chunk‑Kanten zerbrechen.
- **SEM‑Temperatur**: regelt Empfindlichkeit (feine Ironiesignale vs. nur harte Affektwörter).
- **CLU‑Fenster**: definiert Aggregationsfenster für X‑of‑Y.
- **Gates**: `min_total_markers`, `min_segments`; bei Verletzung → `E_GATE_BLOCKED`.
  Quelle: Agent Interface – Live Marker Stream.

Siehe auch: annotierter Beispiel‑Chat (Farbcodes, Familien‑Badges). :contentReference[oaicite:38]{index=38}
