# Marker‑Schema (LD‑3.5) – Kernregeln

## Vier Ebenen & Strukturblöcke

- **ATO**: `pattern` (Token/Regex)
- **SEM**: `composed_of` (≥2 **unterschiedliche** ATOs; CI‑Hook „sem‑composition‑check“)
- **CLU**: `composed_of` (SEMs) + `activation` („AT_LEAST X IN Y messages“, X‑of‑Y)
- **MEMA**: `composed_of` (CLUs) **oder** `detect_class` (Algorithmik)
  Quelle: LD‑3.5 Implementierung/Architektur.

## Universelle Pflichtfelder

Jeder Marker benötigt:

- `id` mit korrektem Präfix (ATO*/SEM*/CLU*/MEMA*)
- `frame{signal, concept, pragmatics, narrative}`
- `examples` mit mindestens **5** realen Beispielen
- exakt **einen** Strukturblock (`pattern` | `composed_of` | `detect_class`)
  Quelle: Leitfaden Erstellung/Migration.
