# Beispiel: Backlog-Slice

## Titel
Progressives Profiling im Onboarding

## Zweck/Nutzen
Reduktion Abbrüche um 10 pp durch gestufte Dateneingabe.

## Beschreibung
Statt 12 Feldern initial nur E-Mail + Passwort, restliche Felder kontextuell.

## Abhängigkeiten
Tracking-Ereignisse, Datenschutzprüfung.

## DoD
A/B-Test aktiv; Konfidenz ≥ 90 %; kein Anstieg von Support-Tickets.

## Metriken/KPIs
Primary: Conversion Onboarding; Secondary: Ticket-Quote.

## Schätzung
JS: 5; Effort: 2 PW

## Hinweise aus KI-Analysen
Edge-Cases markiert: Passwort-Reset-Flow, Mobile-Keyboard.
