# Micro-Experiment Log

| Experiment-ID | Datum gestartet | Verantwortlich | Ausgangshypothese | Ziel-KPI | Schwelle / Erwartungswert | Lernfenster (Sprint) | Ergebnis | Nächste Aktion |
|---------------|-----------------|----------------|-------------------|----------|---------------------------|----------------------|----------|---------------|
|               |                 |                |                   |          |                           |                      |          |               |

## Kontext & Insights
- Beobachteter Trigger (z. B. KPI-Abweichung, Standup-Signal):
- Vorhandene Datenquellen/Dashboards:
- KI-Impulse / Analysen genutzt:

## Review
- Abschlussdatum:
- Entscheid (weiterführen / skalieren / stoppen):
- Übertrag in Retrospektive?
