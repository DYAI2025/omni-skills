# Retrospektive & Methodik-Übernahme (Phase 4)

## Was hat Wert geschaffen?
-

## Wo war Oberflächlichkeit drohend – wie wurde sie verhindert?
-

## Lernzyklen (Code→Test→Critique→Refactor)
-

## Selbst-Evaluation (Sprint-Score 1–5)
- Fokus:
- Flow:
- Klarheit:
- Kommentar zu Ausreißern:

## Monatlicher Deep-Dive (falls zutreffend)
- Wichtigste Muster/Trends:
- Ableitungen für Rollenrotation / Skills:

## Prozessanpassungen (Team-eigen)
-

## Autonomie-Nachweis
- Entscheidungen ohne Coach:
- Review Gates eigenverantwortlich durchgeführt:

## KPI-Abweichungen & Micro-Experimente
- Betroffene KPI(s):
- Hypothese:
- Maßnahmen / Experiment-ID:
- Ergebnis & Lernpunkt:

## Nächste Experiment-/Verbesserungsthese
-
