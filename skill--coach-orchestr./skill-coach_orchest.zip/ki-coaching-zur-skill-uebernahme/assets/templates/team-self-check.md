# Team-Selbstcheck (Sprint & Monat)

## Sprint-Check (Score 1–5)
| Bereich   | Score | Beobachtung / Kommentar |
|-----------|------:|-------------------------|
| Fokus     |      |                         |
| Flow      |      |                         |
| Klarheit  |      |                         |
| Zuverlässigkeit (Commit vs. Delivery) |      |                         |

- Top-Hindernis:
- Spontane Anpassung für nächsten Sprint:
- Verweis auf relevante KPIs / Logs:

## Monats-Deep-Dive
| Thema                | Erkenntnisse | Geplanter Schritt |
|----------------------|--------------|-------------------|
| Muster / Trends      |              |                   |
| Rollenentwicklung    |              |                   |
| Skill-Gaps           |              |                   |
| Autonomie-Grad       |              |                   |

- Zusammenfassung Guarded Autonomy Audit:
- Offene Fragen an Coach/KI:

## Angehängte Artefakte
- Standup-Log:
- Experiment-IDs:
- KPI-Matrix-Version:
