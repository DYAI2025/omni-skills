# Antizipations-Standup (Proaktivitäts-Log)

## Eckdaten
- Datum:
- Facilitator:
- Teilnehmer:
- Sprint / Woche:

## Chancen & Frühindikatoren
- Neue Chancen (Beschreibung, betroffene KPI):
- Frühwarnsignale / Schwellenwerte:

## Risiken & Gegenmaßnahmen
- Risiko:
- Frühzeitige Maßnahme:
- Verantwortlich bis (Datum):

## Lernziele & Experimente
- Individuelles Lernziel (Person → Fokus):
- Geplantes Micro-Experiment (Verweis auf `experiment-log.md`):

## Follow-up
- Entscheidung / Alignment mit Review-Gates:
- Benötigte Support-Impulse durch KI/Coach:
