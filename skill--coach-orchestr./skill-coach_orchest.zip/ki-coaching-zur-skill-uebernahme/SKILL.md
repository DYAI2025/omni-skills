---
name: ki-coaching-zur-skill-uebernahme
description: Bietet ein KI-begleitetes Coaching-Framework für Projektmanagement und Produkt-Backlog, um AI-Impulse in menschliche Kompetenz zu überführen. Nutzt einen Vier-Phasen-Prozess (Ideenfindung, Backlog-Refinement, Priorisierung & Umsetzung, Meisterschaft) mit Guarded Autonomie, expliziten Review Gates und wertbasierter Steuerung.
---

# KI‑begleitetes Coaching zur menschlichen Skill‑Übernahme

## Wann verwenden
- Wenn Teams KI‑Impulse systematisch in **menschlich verstandene, verantwortete Arbeit** überführen sollen.
- Wenn **Projektmanagement** und **Produkt‑Backlog** mit **Maschinengestützter Agiler AI** strukturiert orchestriert werden sollen.
- Wenn **Oberflächliche Umsetzung** vermieden und stattdessen **wertbasierte, überprüfbare Ergebnisse** erreicht werden sollen.

## Eingaben (Inputs)
- Kontext: Zielbild, Problemraum, Randbedingungen, Stakeholder, Risiken.
- Teamdaten: Mitglieder, Rollen, Kapazität, Sprintlänge.
- Qualitätskriterien: KPIs/OKRs, Definition of Done (DoD), Compliance/Policy.
- Artefakt‑Pfad: Ordner für Vorlagen & Ergebnisse (z. B. `assets/`).

## Ausgaben (Outputs)
- Ideation‑Log (siehe `assets/templates/ideation-canvas.md`).
- Backlog‑Slices als **wertschöpfende Chunks** (siehe `assets/templates/backlog-item.md`).
- Bewertungsbögen (WSJF/RICE) und Priorisierungssicht (siehe `assets/examples/example-prioritization-sheet.csv`).
- Review‑Gate‑Protokolle (siehe `assets/templates/review-gate-record.json`).
- Retrospektive & Methodik‑Übernahmedokument (siehe `assets/templates/retrospective.md`).
- Proaktivitäts-Protokolle (siehe `assets/templates/proactive-standup.md`).
- Selbstbewertungs- und Experiment-Log (siehe `assets/templates/team-self-check.md` sowie `assets/templates/experiment-log.md`).

## Rollen & Verantwortlichkeiten (erzwungener Perspektivwechsel)
- **Architekt (DaVinci‑Architect):** Vision, Systemdenken, Annahmen prüfen.
- **Handwerker (Virtuoso‑Craftsman):** präzise Umsetzung, DoD, Qualität.
- **Kritiker (Steve‑Critic):** Werturteil, rigorose Vereinfachung, Faktencheck.
- **Coach:** verankert Struktur, Klarheit, Verlässlichkeit; setzt **Guarded Autonomy** und **Review Gates** durch.
- **KI (Katalysator):** liefert Impulse, Analysen, Vorschläge – **keine Autorität**; Mensch entscheidet final.

## Mechanismus gegen Oberflächlichkeit
- **Explizite Review Gates** je Phase (Ideation, Backlog, Execution, Final).
- **Guarded Autonomy:** KI inspiriert, Mensch verantwortet.
- **Klarheit erzwingen:** „If it can’t be explained clearly, it hasn’t been understood deeply enough.“
- **Wert vor Geschwindigkeit:** „You don’t ship because it’s done. You ship because it matters.“

## Proaktive Teamsteuerung & KPI-Zyklus
- **Antizipations-Standup (wöchentlich):** Team benennt Chancen, Risiken, Lernziele; Coach/Agent spiegelt Muster (Template `proactive-standup.md`).
- **Selbstbewertung (Sprint- & Monatsrhythmus):** Kurzscore 1–5 je Sprint + monatlicher Deep-Dive mit Ursachenanalyse (Template `team-self-check.md`).
- **KPI-Mappings:** Verknüpfe qualitative Beobachtungen mit Kennzahlen (`assets/templates/kpi-matrix.md`); überprüfe Relevanz mindestens quartalsweise.
- **Micro-Experimente:** Jede relevante KPI-Abweichung erzeugt einen Hypothese→A/B→Review-Zyklus, dokumentiert im `experiment-log.md`.
- **Guarded Autonomy Audit:** Team führt vor jedem Gate einen Self-Audit gegen obenstehende Artefakte durch; Coach bestätigt lediglich.

## Workflow/Anweisungen (Vier‑Phasen‑Prozess)

### Phase 1 – Ideenfindung & Emergenz (Divergenz)
1. Problemraum und Constraints klar formulieren (Coach + Architekt).
2. **AI Seeding**: KI generiert Varianten, Szenarien, Gegenrahmungen.
3. **Human Divergence**: Brainstorming/NGT; Empathy Mapping; Annahmen markieren.
4. **Challenge & Discard**: Unviables rigoros verwerfen; Ambivalenz zulassen.
5. Ideation‑Canvas ausfüllen; **Ideation Gate** protokollieren.
   - Leitprinzip: „You are here to ask better questions.“

### Phase 2 – Backlog Refinement & Segmentierung (Konvergenz)
1. Ideen in **testbare, wertschöpfende Chunks** schneiden.
2. Für jeden Chunk **Zweck & DoD** klären; Abhängigkeiten sichtbar machen (KI hilft visualisieren).
3. Backlog‑Vorlage ausfüllen; **Backlog Gate** durchführen (Handwerker + Kritiker).
   - Leitprinzip: „If it can’t be explained clearly, it hasn’t been understood deeply enough.“

### Phase 3 – Wertbasierte Priorisierung & Iterative Umsetzung
1. Bewertungsbögen vorbereiten (WSJF, RICE).
   - `scripts/wsjf_calculator.py` und `scripts/rice_calculator.py` nutzen.
2. Antizipations-Standup durchführen: Risiken, Chancen, Lernziele festhalten (`proactive-standup.md`).
3. Sprint-Selbstscore (1–5) für Fokus, Flow, Klarheit dokumentieren (`team-self-check.md` → Abschnitt Sprint-Check).
4. Umsetzung in kurzen Zyklen: Code → Test → Critique → Refactor; Abweichungen triggern Micro-Experimente (`experiment-log.md`).
5. **Review Gates erzwingen** (Coach): Kriterien konsistent anwenden; Self-Audit results beilegen.
6. **Execution Gate** je Inkrement: Wert, Qualität, Risiko prüfen und KPI-Trend aktualisieren.
   - Leitprinzip: „You don’t ship because it matters.“

### Phase 4 – Meisterschaft & Übernahme der Methodik
1. **Coach zieht sich schrittweise zurück** (doing → enabling).
2. Team dokumentiert und **besitzt** die Methodik; KI wird optionaler Verbündeter/Wissensspeicher; KPI-Matrix & Experiment-Backlog werden teamgeführt.
3. Monatlicher Deep-Dive aus dem `team-self-check.md` nutzen, um Guarded Autonomy nachzuweisen.
4. **Final Gate**: Nachweis methodischer Autonomie, belastbarer Ergebnisse, Lernzyklen; Antizipations- und Experiment-Logs werden geprüft.
   - Leitprinzip: „Mastery is not perfection—it’s the ability to learn faster than failure.“

## Review Gates & Entscheidungen
- Format: JSON‑Record nach Schema in `assets/templates/review-gate-record.json`.
- Validierung: `scripts/review_gate_validator.py <pfad/zur/datei.json>`.
- Gates:
  - **Ideation Gate:** Viabilität + Annahmen geprüft (Architekt + Coach).
  - **Backlog Gate:** Testbarkeit + Zweck je Chunk (Handwerker + Kritiker) + KPI-Matrix aktualisiert.
  - **Execution Gate:** Wertnachweis + Qualität + Risiko (Team + Kritiker); Micro-Experimente & Self-Audits vorlegen.
  - **Final Gate:** Autonomie + Reifegrad (menschliche Aufsicht); vollständige Self-Audit-Referenzen prüfen.

## Metriken (Beispiele)
- Lead-/Cycle‑Time, Flow‑Effizienz, Rework‑Quote, Change‑Fail‑Rate.
- **Reliability as Simplicity:** wiederholbar erfüllte Zusagen vs. Time‑to‑Value.
- Commitment Reliability (Plan vs. Delivery pro Sprint).
- Flow-Stabilität (Varianz der Cycle-Time je Work-Typ).
- Learn Velocity (Anzahl abgeschlossener Micro-Experimente / Sprint).
- Autonomie-Grad (Anteil Entscheidungen ohne Coach/Gate-Intervention).

## Ausgabeformat
- Alle Artefakte als Markdown/CSV/JSON in `assets/`.
- Priorisierungstabelle: CSV mit Scores (WSJF/RICE) und sortierter Reihenfolge.
- Gate‑Protokolle: JSON‑Dateien je Gate.
- Retrospektive: Markdown nach Template.

## Beispiele (kurz & prüfbar)

**Beispiel A – WSJF rechnen**
```bash
python scripts/wsjf_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv
Erwartung: CSV enthält zusätzliche Spalten cod und wsjf, sortiert absteigend nach wsjf.

Beispiel B – RICE rechnen

bash
Code kopieren
python scripts/rice_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv
Erwartung: CSV enthält Spalte rice, sortiert absteigend nach rice.

Beispiel C – Review Gate validieren

bash
Code kopieren
python scripts/review_gate_validator.py assets/templates/review-gate-record.json
Erwartung: Exitcode 0 und Meldung „valid“.

Beispiel D – Rollenrotation planen (3 Sprints)

bash
Code kopieren
python scripts/role_rotation_scheduler.py --team "Ava,Ben,Cem" --sprints 3
Erwartung: Konsolenausgabe mit Sprint‑weise zugewiesenen Rollen (Architect/Craftsman/Critic).
```
