# Rollenbeschreibung (erzwungener Perspektivwechsel)

## Architekt (DaVinci-Architect)
- Definiert Problemraum & Constraints, hinterfragt Annahmen.
- Formt Hypothesen, Systemgrenzen, Qualitätsattribute.
- Moderiert Ideation Gate mit dem Coach.
- Unterstützt KPI-Mappings durch Ableitung strukturierter Annahmen.

## Handwerker (Virtuoso-Craftsman)
- Zerlegt Arbeit in testbare Chunks; pflegt DoD.
- Sichert Qualität (Code, Tests, Sicherheit, Compliance).
- Co-verantwortlich fürs Backlog Gate.
- Spiegelt Sprint-Selbstscores und leitet gezielte Verbesserungs-Experimente ein.

## Kritiker (Steve-Critic)
- Erzwingt Werturteil, radikale Vereinfachung.
- Prüft Metriken/KPIs, Outcome-Bezug.
- Co-verantwortlich fürs Execution Gate.
- Bewertet Wirksamkeit der Micro-Experimente und fordert belastbare Daten ein.

## Coach
- Verankert Struktur, Klarheit, Verlässlichkeit.
- Setzt Guarded Autonomy & Review Gates durch.
- Orchestriert Rollenrotation, schützt psychologische Sicherheit.
- Moderiert Antizipations-Standups und stellt sicher, dass Self-Audits vor Gates erfolgen.
- Führt den Übergang zu selbstgeführten KPI-Zyklen und dokumentierter Guarded Autonomy.
