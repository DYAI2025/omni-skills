# Scoring-Frameworks (WSJF & RICE)

## WSJF (Weighted Shortest Job First)
- Felder: BV (Business Value), TC (Time Criticality), RR (Risk Reduction/Opportunity Enablement), JS (Job Size)
- Formel: Cost of Delay (CoD) = BV + TC + RR; WSJF = CoD / JS
- Skalenempfehlung: 1–10 diskret; JS > 0
- Interpretation: Höherer WSJF ⇒ früher umsetzen.

## RICE
- Felder: Reach, Impact, Confidence, Effort
- Formel: RICE = (Reach * Impact * Confidence) / Effort
- Skalenempfehlung:
  - Reach = Nutzer/Periode (absolut oder normiert)
  - Impact ∈ {0.25, 0.5, 1, 2, 3}
  - Confidence ∈ [0, 1]
  - Effort in Personen-Wochen/-Monaten (Effort > 0)
- Interpretation: Höherer RICE ⇒ höhere Priorität.
