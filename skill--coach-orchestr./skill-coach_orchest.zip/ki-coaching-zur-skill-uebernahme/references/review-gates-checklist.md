# Review Gates – Checkliste

## Gemeinsame Pflichtfelder (pro Gate, im JSON-Record zu hinterlegen)
- gate_name: "Ideation|Backlog|Execution|Final"
- date: ISO-Datum (YYYY-MM-DD)
- reviewers: Liste von Namen/Rollen
- decision: "approve" | "changes" | "reject"
- rationale: Begründung (prägnant, faktenbasiert)
- risks: Top-Risiken + Gegenmaßnahmen
- next_actions: Nächste Schritte mit Verantwortlichen & Termin
- self_audit_reference: Verweis auf Standup-/Selbstcheck-/Experiment-Log (mindestens eins)

## Zusatzkriterien nach Gate
- Ideation: Annahmen explizit? Viabilität geprüft? Verwerfungen dokumentiert?
- Backlog: Zweck je Chunk klar? DoD testbar? Abhängigkeiten sichtbar? KPI-Matrix aktualisiert?
- Execution: KPI-Bezug vorhanden? Qualität (Tests/Security) erfüllt? Micro-Experimente bewertet?
- Final: Autonomie nachgewiesen? Methodik dokumentiert & im Besitz des Teams? Self-Audits vollständig?
