# KI-Coaching zur Skill-Übernahme – README

## Überblick
Dieses Skill-Paket befähigt einen KI-gestützten Coach, Teams bei der Überführung von KI-Impulsen in eigenverantwortliche, wertorientierte Arbeit zu unterstützen. Der Skill orchestriert einen Vier-Phasen-Prozess (Ideation, Backlog, Execution, Mastery) und bindet proaktive Routinen, Self-Audits und KPI-gestützte Entscheidungen ein. Zentrale Leitplanken sind Guarded Autonomy, explizite Review Gates und das konsequente Sichtbarmachen von Lernzyklen.

## Hauptziele
- **Proaktives Teamverhalten stärken:** Antizipations-Standups machen Chancen, Risiken und Lernziele früh sichtbar.
- **Selbstständige Teamevaluation fördern:** Sprint-Self-Scores und Monats-Deep-Dives halten Verantwortlichkeit im Team.
- **Datenbasierte Entscheidungen treffen:** KPI-Matrix und Micro-Experimente verknüpfen qualitative Beobachtungen mit messbaren Trends.
- **Guarded Autonomy sichern:** Die KI liefert Impulse, das Team trifft Entscheidungen; der Coach validiert nur noch Self-Audits.

## Verzeichnisstruktur (Kurzfassung)
```
ki-coaching-zur-skill-uebernahme/
├─ README.md                   ← diese Datei
├─ SKILL.md                    ← Einsatzanleitung & Prozessbeschreibung
├─ references/                 ← Rollen, State Machine, Gate-Checkliste
├─ scripts/                    ← WSJF, RICE, Rollenrotation, Gate-Validator
└─ assets/
   ├─ templates/               ← Artefaktvorlagen & Logs
   └─ examples/                ← Ausgefüllte Beispieldateien
```

## Anwendungsschritte
1. **Initiale Vorbereitung**
   - `SKILL.md` lesen, um den Vier-Phasen-Flow zu verstehen.
   - `references/state-machine.mmd` (Mermaid) zur Visualisierung des Prozesses nutzen.
   - Rollenzuordnung anhand `references/role-definitions.md` klären.

2. **Phase 1 – Ideation**
   - Problemraum und Constraints dokumentieren (`ideation-canvas.md`).
   - Erste Antizipations-Standups vorbereiten (`proactive-standup.md`).
   - Gate-Record mit Self-Audit-Referenz anlegen (`review-gate-record.json`).

3. **Phase 2 – Backlog Refinement**
   - Ideen in testbare Chunks schneiden (`backlog-item.md`).
   - KPI-Einflüsse festhalten (`kpi-matrix.md`).
   - Backlog Gate nur mit vollständigem Self-Audit freigeben.

4. **Phase 3 – Priorisierung & Umsetzung**
   - Priorisierung über `scripts/wsjf_calculator.py` und `scripts/rice_calculator.py` ausführen.
   - Sprint-Selbstscore im `team-self-check.md` erfassen.
   - Abweichungen als Micro-Experimente dokumentieren (`experiment-log.md`).
   - Execution Gate inkl. Self-Audit-Referenz passieren.

5. **Phase 4 – Meisterschaft**
   - Coach zieht sich zurück; Team führt KPI-Matrix & Experimente.
   - Retrospektive (`retrospective.md`) mit Self-Score, KPI-Abweichungen und Guarded Autonomy Audit erweitern.
   - Final Gate prüft Autonomie & Lernzyklen (Validator nutzen).

## Methodenübersicht je Phase

### Phase 1 – Ideation & Emergenz
- **AI Seeding & Gegenrahmung:** KI generiert Szenarien/Varianten; Menschen bewerten (Dokumentation im `ideation-canvas.md`).
- **Human Divergence (Brainstorming/NGT):** Moderierter Ideation-Workshop mit Fokus auf Annahmen, Constraints und Perspektivwechsel.
- **Challenge & Discard:** Harte Bewertungsschleife, um untragbare Ideen zu verwerfen und Lernfragen abzuleiten.
- **Risk Anticipation Standup (Preview):** Erste Version des `proactive-standup.md`, um Frühwarnsignale festzuhalten.
- **Ideation Gate Self-Audit:** Gate-Record inklusive Verweise auf Standup, Self-Check und Experimente im `review-gate-record.json` vorbereiten.

### Phase 2 – Backlog Refinement & Segmentierung
- **Value/Outcome Slicing:** Ideen in testbare, wertstiftende Chunks schneiden (`backlog-item.md`).
- **Definition-of-Done & DoR Schärfung:** Qualitäts- und Testkriterien explizit machen; KI liefert Impulse, Team priorisiert.
- **Dependency Mapping & Visualisierung:** Verknüpfungen dokumentieren; optional ergänzende Diagramme im `references/`-Ordner.
- **KPI-Mapping:** Auswirkungen auf KPI-Matrix identifizieren und im Template ergänzen.
- **Backlog Gate Audit:** Self-Audit mit Fokus auf Testbarkeit, KPI-Reife und Guarded Autonomy vor dem Gate.

### Phase 3 – Wertbasierte Priorisierung & Iterative Umsetzung
- **Quantitative Priorisierung:** WSJF- und RICE-Skripte für kontinuierliche Score-Updates verwenden.
- **Antizipations-Standup (wöchentlich):** Chancen, Risiken, Lernziele, Verantwortlichkeiten im `proactive-standup.md` festhalten.
- **Sprint Self-Check:** Fokus/Flow/Klarheit/Zuverlässigkeit im `team-self-check.md` bewerten.
- **Micro-Experiment Loop:** KPI-Abweichungen triggern Einträge im `experiment-log.md` (Hypothese → Test → Review).
- **Role Rotation Scheduler:** `role_rotation_scheduler.py` nutzen, um Perspektivwechsel zu sichern.
- **Execution Gate Audit:** Kombination aus KPIs, Experiment-Ergebnissen und Self-Audit-Daten prüfen, bevor das Gate passiert wird.

### Phase 4 – Meisterschaft & Methodik-Übernahme
- **Guarded Autonomy Audit:** Team führt eigenverantwortlich das Audit und dokumentiert es in Retrospektive und Self-Check.
- **Knowledge Transfer & Enablement:** Lessons Learned, Templates und Experiment-Ergebnisse werden in Team-wartbare Wissensspeicher überführt.
- **Retrospektive Deep-Dive:** `retrospective.md` um KPI-Abweichungen, Self-Score und Experiment-Outcome ergänzen.
- **Final Gate Review:** KI/Coach bestätigt nur noch Vollständigkeit der Self-Audit-Referenzen und Autonomie-Nachweise.
- **Kontinuierliche KPI-Anpassung:** Zielwerte der `kpi-matrix.md` regelmäßig evaluieren, um Reifegrad widerzuspiegeln.

## Testbarkeit & Validierung
- **Skripte:**
  - `python3 scripts/wsjf_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv`
  - `python3 scripts/rice_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv`
  - `python3 scripts/role_rotation_scheduler.py --team "Ava,Ben,Cem" --sprints 3`
  - `python3 scripts/review_gate_validator.py assets/templates/review-gate-record.json`
- **State-Machine:** Mermaid-Datei in kompatiblen Editoren rendern.
- **Self-Audit-Konsistenz:** Validator prüft Pflichtfelder inkl. `self_audit_reference`; schlägt fehl, wenn Verweise auf Standup-, Self-Check- oder Experiment-Logs fehlen.

## Anforderungen & Voraussetzungen
- Python ≥ 3.8 (für Skripte).
- Möglichkeit, Markdown/CSV/JSON zu bearbeiten.
- Optional: Mermaid-Unterstützung (z. B. VS Code Plugin) zum Anzeigen der State Machine.

## Erweiterung zur Multi-Skill-AI-Coach-Einheit
Für einen autonomen Multi-Skill Team Coach empfiehlt sich eine modulare Skill-Flotte:
1. **Strategic Alignment Skill** – Übersetzt Unternehmensziele in messbare Team-KPIs, synchronisiert OKRs und liefert Zielpfad-Analysen.
2. **Knowledge Synthesis Skill** – Aggregiert Domänenwissen, Referenzen und Compliance-Vorgaben, um Ideation/Backlog mit kontextualisierten Insights zu versorgen.
3. **Risk & Resilience Skill** – Identifiziert kontinuierlich Risiken (technisch, organisatorisch, Compliance), bewertet Gegenmaßnahmen und koppelt sie an Review Gates.
4. **Delivery Analytics Skill** – Überwacht Delivery-Metriken (Lead/Cycle Time, Flow) in Echtzeit, erzeugt Alerts und Prognosen.
5. **Team Dynamics & Wellbeing Skill** – Erfasst psychologische Sicherheit, Engagement und Kapazitätsrisiken; schlägt Interventionen vor.
6. **Learning & Enablement Skill** – Kuratiert Lernpfade, Micro-Trainings und Wissensübergabe, damit Autonomie nachhaltig wächst.
7. **Governance & Compliance Skill** – Prüft automatisch Einhaltung regulatorischer Anforderungen, dokumentiert Entscheidungen und Audit-Trails.

Durch orchestriertes Zusammenspiel dieser Skills entsteht eine Multi-Agent-Coach-Einheit, die strategische Klarheit, operatives Delivery-Tracking, Teamgesundheit und Regelkonformität integriert – mit Guarded Autonomy als Leitprinzip.

## Weiteres Vorgehen
- Templates für reale Projekte kopieren und mit Teamdaten füllen.
- KPI-Zielwerte (B–E in `kpi-matrix.md`) gemeinsam festlegen.
- Regelmäßige Retrospektiven nutzen, um den Skill an Teamkontext und Reifegrad anzupassen.
- Folge-Skills sukzessive integrieren, um den Coach über Teamgrenzen hinaus skalierbar zu machen.
