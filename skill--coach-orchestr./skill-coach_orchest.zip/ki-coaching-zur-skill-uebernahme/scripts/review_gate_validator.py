#!/usr/bin/env python3
"""
Validiert Review-Gate-JSON nach Pflichtfeldern.
Verwendung:
  python review_gate_validator.py <record.json>
Exitcode 0 bei Erfolg, sonst != 0.
"""
import sys, json, datetime

REQUIRED = ["gate_name","date","reviewers","decision","rationale","risks","next_actions","self_audit_reference"]
GATES = {"Ideation","Backlog","Execution","Final"}
DECISIONS = {"approve","changes","reject"}

def die(msg, code=1):
    print(f"[Gate] {msg}", file=sys.stderr)
    sys.exit(code)

def main():
    if len(sys.argv) < 2:
        die("Bitte JSON-Datei angeben.")
    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        die(f"Kann JSON nicht lesen: {e}")

    for k in REQUIRED:
        if k not in data:
            die(f"Pflichtfeld fehlt: {k}")
    if data["gate_name"] not in GATES:
        die(f"gate_name ungültig: {data['gate_name']}")
    try:
        datetime.date.fromisoformat(data["date"])
    except ValueError:
        die("date muss ISO-Format YYYY-MM-DD haben.")
    if not isinstance(data["reviewers"], list) or not data["reviewers"]:
        die("reviewers muss nicht-leere Liste sein.")
    if data["decision"] not in DECISIONS:
        die(f"decision ungültig: {data['decision']}")
    # Minimalinhalte prüfen
    for fld in ["rationale","risks","next_actions"]:
        if not str(data[fld]).strip():
            die(f"{fld} darf nicht leer sein.")
    ref = data["self_audit_reference"]
    if not isinstance(ref, dict) or not any(ref.values()):
        die("self_audit_reference muss Objekt mit mind. einem Verweis sein.")
    allowed = {"standup_log","self_check","experiment_log"}
    unknown = set(ref.keys()) - allowed
    if unknown:
        die(f"self_audit_reference enthält unbekannte Schlüssel: {', '.join(sorted(unknown))}")
    if not any(str(ref.get(k, "")).strip() for k in allowed):
        die("self_audit_reference benötigt Verweis auf Standup-, Self-Check- oder Experiment-Log.")
    print("[Gate] valid")
    sys.exit(0)

if __name__ == "__main__":
    main()
