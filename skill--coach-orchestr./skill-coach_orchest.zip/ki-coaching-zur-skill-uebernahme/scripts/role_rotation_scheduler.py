#!/usr/bin/env python3
"""
Rollenrotation-Planer
Erzeugt eine Sprint-weise Zuordnung der Rollen Architect/Craftsman/Critic.
Verwendung:
  python role_rotation_scheduler.py --team "Ava,Ben,Cem" --sprints 3 [--start 0]
"""
import sys, argparse, itertools

ROLES = ["Architect", "Craftsman", "Critic"]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--team", required=True, help="Kommagetrennte Liste von Namen")
    p.add_argument("--sprints", type=int, required=True)
    p.add_argument("--start", type=int, default=0, help="Startindex im Team für Architect")
    args = p.parse_args()

    team = [t.strip() for t in args.team.split(",") if t.strip()]
    if len(team) < len(ROLES):
        print("[Rotate] Mind. 3 Teammitglieder benötigt.", file=sys.stderr)
        sys.exit(1)

    print("sprint,Architect,Craftsman,Critic")
    idx = args.start % len(team)
    ring = itertools.cycle(range(len(team)))
    # Vorspulen zu Start
    for _ in range(idx):
        next(ring)

    for s in range(1, args.sprints+1):
        order = []
        for _ in range(len(ROLES)):
            order.append(team[next(ring)])
        print(f"{s},{order[0]},{order[1]},{order[2]}")

if __name__ == "__main__":
    main()
