Im Folgenden erhältst du ein vollständiges, sofort nutzbares Skill‑Paket im geforderten Format — inklusive Dateibaum, aller Dateien (mit vollständigen Inhalten), sowie Validierungs‑ und Packaging‑Hinweisen.

1) FILETREE
pgsql
Code kopieren
ki-coaching-zur-skill-uebernahme/
├─ SKILL.md
├─ references/
│  ├─ state-machine.mmd
│  ├─ role-definitions.md
│  ├─ review-gates-checklist.md
│  └─ scoring-frameworks.md
├─ scripts/
│  ├─ wsjf_calculator.py
│  ├─ rice_calculator.py
│  ├─ role_rotation_scheduler.py
│  └─ review_gate_validator.py
└─ assets/
   ├─ templates/
   │  ├─ ideation-canvas.md
   │  ├─ backlog-item.md
   │  ├─ review-gate-record.json
   │  ├─ retrospective.md
   │  └─ kpi-matrix.md
   └─ examples/
      ├─ example-ideation-session.md
      ├─ example-backlog-slice.md
      └─ example-prioritization-sheet.csv
2) ALLE DATEIEN
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/SKILL.md
---
name: ki-coaching-zur-skill-uebernahme
description: Bietet ein KI-begleitetes Coaching-Framework für Projektmanagement und Produkt-Backlog, um AI-Impulse in menschliche Kompetenz zu überführen. Nutzt einen Vier-Phasen-Prozess (Ideenfindung, Backlog-Refinement, Priorisierung & Umsetzung, Meisterschaft) mit Guarded Autonomy, expliziten Review Gates und wertbasierter Steuerung.
---

# KI‑begleitetes Coaching zur menschlichen Skill‑Übernahme

## Wann verwenden
- Wenn Teams KI‑Impulse systematisch in **menschlich verstandene, verantwortete Arbeit** überführen sollen.
- Wenn **Projektmanagement** und **Produkt‑Backlog** mit **Maschinengestützter Agiler AI** strukturiert orchestriert werden sollen.
- Wenn **Oberflächliche Umsetzung** vermieden und stattdessen **wertbasierte, überprüfbare Ergebnisse** erreicht werden sollen.

## Eingaben (Inputs)
- Kontext: Zielbild, Problemraum, Randbedingungen, Stakeholder, Risiken.
- Teamdaten: Mitglieder, Rollen, Kapazität, Sprintlänge.
- Qualitätskriterien: KPIs/OKRs, Definition of Done (DoD), Compliance/Policy.
- Artefakt‑Pfad: Ordner für Vorlagen & Ergebnisse (z. B. `assets/`).

## Ausgaben (Outputs)
- Ideation‑Log (siehe `assets/templates/ideation-canvas.md`).
- Backlog‑Slices als **wertschöpfende Chunks** (siehe `assets/templates/backlog-item.md`).
- Bewertungsbögen (WSJF/RICE) und Priorisierungssicht (siehe `assets/examples/example-prioritization-sheet.csv`).
- Review‑Gate‑Protokolle (siehe `assets/templates/review-gate-record.json`).
- Retrospektive & Methodik‑Übernahmedokument (siehe `assets/templates/retrospective.md`).

## Rollen & Verantwortlichkeiten (erzwungener Perspektivwechsel)
- **Architekt (DaVinci‑Architect):** Vision, Systemdenken, Annahmen prüfen.
- **Handwerker (Virtuoso‑Craftsman):** präzise Umsetzung, DoD, Qualität.
- **Kritiker (Steve‑Critic):** Werturteil, rigorose Vereinfachung, Faktencheck.
- **Coach:** verankert Struktur, Klarheit, Verlässlichkeit; setzt **Guarded Autonomy** und **Review Gates** durch.
- **KI (Katalysator):** liefert Impulse, Analysen, Vorschläge – **keine Autorität**; Mensch entscheidet final.

## Mechanismus gegen Oberflächlichkeit
- **Explizite Review Gates** je Phase (Ideation, Backlog, Execution, Final).
- **Guarded Autonomy:** KI inspiriert, Mensch verantwortet.
- **Klarheit erzwingen:** „If it can’t be explained clearly, it hasn’t been understood deeply enough.“
- **Wert vor Geschwindigkeit:** „You don’t ship because it’s done. You ship because it matters.“

## Workflow/Anweisungen (Vier‑Phasen‑Prozess)

### Phase 1 – Ideenfindung & Emergenz (Divergenz)
1. Problemraum und Constraints klar formulieren (Coach + Architekt).
2. **AI Seeding**: KI generiert Varianten, Szenarien, Gegenrahmungen.
3. **Human Divergence**: Brainstorming/NGT; Empathy Mapping; Annahmen markieren.
4. **Challenge & Discard**: Unviables rigoros verwerfen; Ambivalenz zulassen.
5. Ideation‑Canvas ausfüllen; **Ideation Gate** protokollieren.
   - Leitprinzip: „You are here to ask better questions.“

### Phase 2 – Backlog Refinement & Segmentierung (Konvergenz)
1. Ideen in **testbare, wertschöpfende Chunks** schneiden.
2. Für jeden Chunk **Zweck & DoD** klären; Abhängigkeiten sichtbar machen (KI hilft visualisieren).
3. Backlog‑Vorlage ausfüllen; **Backlog Gate** durchführen (Handwerker + Kritiker).
   - Leitprinzip: „If it can’t be explained clearly, it hasn’t been understood deeply enough.“

### Phase 3 – Wertbasierte Priorisierung & Iterative Umsetzung
1. Bewertungsbögen vorbereiten (WSJF, RICE).
   - `scripts/wsjf_calculator.py` und `scripts/rice_calculator.py` nutzen.
2. **Review Gates erzwingen** (Coach): Kriterien konsistent anwenden.
3. Umsetzung in kurzen Zyklen: Code → Test → Critique → Refactor.
4. **Execution Gate** je Inkrement: Wert, Qualität, Risiko prüfen.
   - Leitprinzip: „You don’t ship because it matters.“

### Phase 4 – Meisterschaft & Übernahme der Methodik
1. **Coach zieht sich schrittweise zurück** (doing → enabling).
2. Team dokumentiert und **besitzt** die Methodik; KI wird optionaler Verbündeter/Wissensspeicher.
3. **Final Gate**: Nachweis methodischer Autonomie, belastbarer Ergebnisse, Lernzyklen.
   - Leitprinzip: „Mastery is not perfection—it’s the ability to learn faster than failure.“

## Review Gates & Entscheidungen
- Format: JSON‑Record nach Schema in `assets/templates/review-gate-record.json`.
- Validierung: `scripts/review_gate_validator.py <pfad/zur/datei.json>`.
- Gates:
  - **Ideation Gate:** Viabilität + Annahmen geprüft (Architekt + Coach).
  - **Backlog Gate:** Testbarkeit + Zweck je Chunk (Handwerker + Kritiker).
  - **Execution Gate:** Wertnachweis + Qualität + Risiko (Team + Kritiker).
  - **Final Gate:** Autonomie + Reifegrad (menschliche Aufsicht).

## Metriken (Beispiele)
- Lead-/Cycle‑Time, Flow‑Effizienz, Rework‑Quote, Change‑Fail‑Rate.
- **Reliability as Simplicity:** wiederholbar erfüllte Zusagen vs. Time‑to‑Value.

## Ausgabeformat
- Alle Artefakte als Markdown/CSV/JSON in `assets/`.
- Priorisierungstabelle: CSV mit Scores (WSJF/RICE) und sortierter Reihenfolge.
- Gate‑Protokolle: JSON‑Dateien je Gate.
- Retrospektive: Markdown nach Template.

## Beispiele (kurz & prüfbar)

**Beispiel A – WSJF rechnen**
```bash
python scripts/wsjf_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv
Erwartung: CSV enthält zusätzliche Spalten cod und wsjf, sortiert absteigend nach wsjf.

Beispiel B – RICE rechnen

bash
Code kopieren
python scripts/rice_calculator.py assets/examples/example-prioritization-sheet.csv --out assets/examples/example-prioritization-sheet.csv
Erwartung: CSV enthält Spalte rice, sortiert absteigend nach rice.

Beispiel C – Review Gate validieren

bash
Code kopieren
python scripts/review_gate_validator.py assets/templates/review-gate-record.json
Erwartung: Exitcode 0 und Meldung „valid“.

Beispiel D – Rollenrotation planen (3 Sprints)

bash
Code kopieren
python scripts/role_rotation_scheduler.py --team "Ava,Ben,Cem" --sprints 3
Erwartung: Konsolenausgabe mit Sprint‑weise zugewiesenen Rollen (Architect/Craftsman/Critic).

pgsql
Code kopieren

```md
# path: ki-coaching-zur-skill-uebernahme/references/state-machine.mmd
%% Mermaid State Machine: Vier-Phasen-Prozess
stateDiagram-v2
    [*] --> Ideation
    Ideation --> Backlog: Ideation Gate (pass)
    Ideation --> Ideation: Iterate (Code→Test→Critique→Refactor)
    Backlog --> Execution: Backlog Gate (pass)
    Backlog --> Ideation: Erkenntnisse / Lücken
    Execution --> Execution: Short Cycles + Execution Gate
    Execution --> Mastery: Reifegrad erreicht
    Execution --> Backlog: Re-Slicing / neue Erkenntnisse
    Mastery --> [*]
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/references/role-definitions.md
# Rollenbeschreibung (erzwungener Perspektivwechsel)

## Architekt (DaVinci-Architect)
- Definiert Problemraum & Constraints, hinterfragt Annahmen.
- Formt Hypothesen, Systemgrenzen, Qualitätsattribute.
- Moderiert Ideation Gate mit dem Coach.

## Handwerker (Virtuoso-Craftsman)
- Zerlegt Arbeit in testbare Chunks; pflegt DoD.
- Sichert Qualität (Code, Tests, Sicherheit, Compliance).
- Co‑verantwortlich fürs Backlog Gate.

## Kritiker (Steve-Critic)
- Erzwingt Werturteil, radikale Vereinfachung.
- Prüft Metriken/KPIs, Outcome‑Bezug.
- Co‑verantwortlich fürs Execution Gate.

## Coach
- Verankert Struktur, Klarheit, Verlässlichkeit.
- Setzt Guarded Autonomy & Review Gates durch.
- Orchestriert Rollenrotation, schützt psychologische Sicherheit.
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/references/review-gates-checklist.md
# Review Gates – Checkliste

## Gemeinsame Pflichtfelder (pro Gate, im JSON-Record zu hinterlegen)
- gate_name: "Ideation|Backlog|Execution|Final"
- date: ISO‑Datum (YYYY‑MM‑DD)
- reviewers: Liste von Namen/Rollen
- decision: "approve" | "changes" | "reject"
- rationale: Begründung (prägnant, faktenbasiert)
- risks: Top‑Risiken + Gegenmaßnahmen
- next_actions: Nächste Schritte mit Verantwortlichen & Termin

## Zusatzkriterien nach Gate
- Ideation: Annahmen explizit? Viabilität geprüft? Verwerfungen dokumentiert?
- Backlog: Zweck je Chunk klar? DoD testbar? Abhängigkeiten sichtbar?
- Execution: KPI‑Bezug vorhanden? Qualität (Tests/Security) erfüllt?
- Final: Autonomie nachgewiesen? Methodik dokumentiert & im Besitz des Teams?
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/references/scoring-frameworks.md
# Scoring-Frameworks (WSJF & RICE)

## WSJF (Weighted Shortest Job First)
- Felder: BV (Business Value), TC (Time Criticality), RR (Risk Reduction/Opportunity Enablement), JS (Job Size)
- Formel: Cost of Delay (CoD) = BV + TC + RR; WSJF = CoD / JS
- Skalenempfehlung: 1–10 diskret; JS > 0
- Interpretation: Höherer WSJF ⇒ früher umsetzen.

## RICE
- Felder: Reach, Impact, Confidence, Effort
- Formel: RICE = (Reach * Impact * Confidence) / Effort
- Skalenempfehlung:
  - Reach = Nutzer/Periode (absolut oder normiert)
  - Impact ∈ {0.25, 0.5, 1, 2, 3}
  - Confidence ∈ [0, 1]
  - Effort in Personen‑Wochen/‑Monaten (Effort > 0)
- Interpretation: Höherer RICE ⇒ höhere Priorität.
python
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/scripts/wsjf_calculator.py
#!/usr/bin/env python3
"""
WSJF-Rechner
Liest eine CSV mit Spalten: id,title,bv,tc,rr,js
Schreibt Spalten: cod,wsjf und sortiert absteigend nach wsjf.
Verwendung:
  python wsjf_calculator.py <input.csv> --out <output.csv>
"""
import csv, sys

def die(msg, code=1):
    print(f"[WSJF] {msg}", file=sys.stderr)
    sys.exit(code)

def main():
    if len(sys.argv) < 2:
        die("Bitte CSV-Datei angeben. Siehe Header in Datei assets/examples/example-prioritization-sheet.csv")
    infile = sys.argv[1]
    outfile = None
    if "--out" in sys.argv:
        idx = sys.argv.index("--out")
        if idx+1 < len(sys.argv):
            outfile = sys.argv[idx+1]
    if outfile is None:
        outfile = infile

    rows = []
    with open(infile, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            try:
                bv = float(row["bv"])
                tc = float(row["tc"])
                rr = float(row["rr"])
                js = float(row["js"])
                if js <= 0:
                    die(f"Job Size (js) muss > 0 sein (id={row.get('id')})")
                cod = bv + tc + rr
                wsjf = cod / js
                row["cod"] = f"{cod:.4f}"
                row["wsjf"] = f"{wsjf:.4f}"
                rows.append(row)
            except KeyError as e:
                die(f"Fehlende Spalte: {e}")
            except ValueError:
                die(f"Nicht-numerischer Wert entdeckt (id={row.get('id')}).")
    # Sortieren
    rows.sort(key=lambda x: float(x["wsjf"]), reverse=True)
    with open(outfile, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"[WSJF] geschrieben: {outfile} (Datensätze: {len(rows)})")

if __name__ == "__main__":
    main()
python
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/scripts/rice_calculator.py
#!/usr/bin/env python3
"""
RICE-Rechner
Liest eine CSV mit Spalten: id,title,reach,impact,confidence,effort
Schreibt Spalte: rice und sortiert absteigend nach rice.
Verwendung:
  python rice_calculator.py <input.csv> --out <output.csv>
"""
import csv, sys

def die(msg, code=1):
    print(f"[RICE] {msg}", file=sys.stderr)
    sys.exit(code)

def main():
    if len(sys.argv) < 2:
        die("Bitte CSV-Datei angeben. Siehe Header in Datei assets/examples/example-prioritization-sheet.csv")
    infile = sys.argv[1]
    outfile = None
    if "--out" in sys.argv:
        idx = sys.argv.index("--out")
        if idx+1 < len(sys.argv):
            outfile = sys.argv[idx+1]
    if outfile is None:
        outfile = infile

    rows = []
    with open(infile, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            try:
                reach = float(row["reach"])
                impact = float(row["impact"])
                confidence = float(row["confidence"])
                effort = float(row["effort"])
                if effort <= 0:
                    die(f"Effort muss > 0 sein (id={row.get('id')})")
                rice = (reach * impact * confidence) / effort
                row["rice"] = f"{rice:.4f}"
                rows.append(row)
            except KeyError as e:
                die(f"Fehlende Spalte: {e}")
            except ValueError:
                die(f"Nicht-numerischer Wert entdeckt (id={row.get('id')}).")
    rows.sort(key=lambda x: float(x["rice"]), reverse=True)
    with open(outfile, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"[RICE] geschrieben: {outfile} (Datensätze: {len(rows)})")

if __name__ == "__main__":
    main()
python
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/scripts/role_rotation_scheduler.py
#!/usr/bin/env python3
"""
Rollenrotation-Planer
Erzeugt eine Sprint-weise Zuordnung der Rollen Architect/Craftsman/Critic.
Verwendung:
  python role_rotation_scheduler.py --team "Ava,Ben,Cem" --sprints 3 [--start 0]
"""
import sys, argparse, itertools

ROLES = ["Architect", "Craftsman", "Critic"]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--team", required=True, help="Kommagetrennte Liste von Namen")
    p.add_argument("--sprints", type=int, required=True)
    p.add_argument("--start", type=int, default=0, help="Startindex im Team für Architect")
    args = p.parse_args()

    team = [t.strip() for t in args.team.split(",") if t.strip()]
    if len(team) < len(ROLES):
        print("[Rotate] Mind. 3 Teammitglieder benötigt.", file=sys.stderr)
        sys.exit(1)

    print("sprint,Architect,Craftsman,Critic")
    idx = args.start % len(team)
    ring = itertools.cycle(range(len(team)))
    # Vorspulen zu Start
    for _ in range(idx): next(ring)

    for s in range(1, args.sprints+1):
        order = []
        for _ in range(len(ROLES)):
            order.append(team[next(ring)])
        print(f"{s},{order[0]},{order[1]},{order[2]}")

if __name__ == "__main__":
    main()
python
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/scripts/review_gate_validator.py
#!/usr/bin/env python3
"""
Validiert Review-Gate-JSON nach Pflichtfeldern.
Verwendung:
  python review_gate_validator.py <record.json>
Exitcode 0 bei Erfolg, sonst != 0.
"""
import sys, json, datetime

REQUIRED = ["gate_name","date","reviewers","decision","rationale","risks","next_actions"]
GATES = {"Ideation","Backlog","Execution","Final"}
DECISIONS = {"approve","changes","reject"}

def die(msg, code=1):
    print(f"[Gate] {msg}", file=sys.stderr)
    sys.exit(code)

def main():
    if len(sys.argv) < 2:
        die("Bitte JSON-Datei angeben.")
    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        die(f"Kann JSON nicht lesen: {e}")

    for k in REQUIRED:
        if k not in data:
            die(f"Pflichtfeld fehlt: {k}")
    if data["gate_name"] not in GATES:
        die(f"gate_name ungültig: {data['gate_name']}")
    try:
        datetime.date.fromisoformat(data["date"])
    except ValueError:
        die("date muss ISO-Format YYYY-MM-DD haben.")
    if not isinstance(data["reviewers"], list) or not data["reviewers"]:
        die("reviewers muss nicht-leere Liste sein.")
    if data["decision"] not in DECISIONS:
        die(f"decision ungültig: {data['decision']}")
    # Minimalinhalte prüfen
    for fld in ["rationale","risks","next_actions"]:
        if not str(data[fld]).strip():
            die(f"{fld} darf nicht leer sein.")
    print("[Gate] valid")
    sys.exit(0)

if __name__ == "__main__":
    main()
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/templates/ideation-canvas.md
# Ideation Canvas (Phase 1 – Divergenz)

## Problemraum & Constraints
- Problem:
- Zielbild:
- Randbedingungen:

## Annahmen & Gegenannahmen
- Annahme A:
- Gegenannahme A′:

## AI Seeding – Impulse (Kurzliste)
- Impuls 1:
- Impuls 2:
- Impuls 3:

## Human Divergence (NGT/Brainstorming)
- Idee #1:
- Idee #2:
- Idee #3:

## Challenge & Discard (Begründete Verwerfungen)
- Verworfen: <Idee> — Grund:
- Verworfen: <Idee> — Grund:

## Kandidaten für Phase 2
- Kandidat K1:
- Kandidat K2:

## Ideation Gate – Ergebnis
- Viabilität: ☐ Ja ☐ Nein
- Offene Risiken:
- Entscheidung/Next Steps:
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/templates/backlog-item.md
# Backlog-Chunk (Phase 2 – Konvergenz)

## Titel
-

## Zweck/Nutzen
- Nutzerwert / Business Impact / Technical Debt Reduktion:

## Beschreibung (klar & testbar)
-

## Abhängigkeiten
-

## DoD (Definition of Done)
- Testfälle:
- Sicherheits-/Compliance-Kriterien:
- Akzeptanzkriterien:

## Metriken/KPIs
- Primär:
- Sekundär:

## Schätzung
- Job Size (JS):
- Effort:

## Hinweise aus KI-Analysen (optional)
- Muster/Lücken:
json
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/templates/review-gate-record.json
{
  "gate_name": "Ideation",
  "date": "2025-01-10",
  "reviewers": ["Coach", "Architect"],
  "decision": "approve",
  "rationale": "Annahmen explizit, unrealistische Pfade verworfen, klarer Problemrahmen.",
  "risks": "Unklare Datenqualität in Segment B – Messplan in Phase 3 erforderlich.",
  "next_actions": "Transfer von K1/K2 in Phase 2 und Zerlegung in testbare Chunks."
}
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/templates/retrospective.md
# Retrospektive & Methodik-Übernahme (Phase 4)

## Was hat Wert geschaffen?
-

## Wo war Oberflächlichkeit drohend – wie wurde sie verhindert?
-

## Lernzyklen (Code→Test→Critique→Refactor)
-

## Prozessanpassungen (Team-eigen)
-

## Autonomie-Nachweis
- Entscheidungen ohne Coach:
- Review Gates eigenverantwortlich durchgeführt:

## Nächste Experiment-/Verbesserungsthese
-
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/templates/kpi-matrix.md
# KPI-Matrix

| KPI                  | Definition                               | Zielwert | Messmethode                 | Review-Zyklus |
|----------------------|-------------------------------------------|---------:|-----------------------------|---------------|
| Time to Value        | Zeit bis erster Nutzerwert                |    ≤ X d | Release + Nutzersignal      | Sprintweise   |
| Lead Time            | Start → Done                              |    ≤ Y d | Board-Events                | Sprintweise   |
| Change Fail Rate     | % Changes mit Rückroll/Hotfix             |     ≤ Z% | Release/Incident-Logs       | Sprintweise   |
| Flow Efficiency      | Wertschöpfende Zeit / Durchlaufzeit       |   ≥ A %  | Board + WIP-Zeiten          | Sprintweise   |
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/examples/example-ideation-session.md
# Beispiel: Ideation-Session (Kurzprotokoll)

- Problem: Onboarding-Abbruchquote > 35%
- AI Seeding Output (Auszug): 5 Szenarien, 3 Gegenrahmungen
- Human Divergence: 18 Ideen, 7 verworfen (begr.), 3 Kandidaten (K1–K3)
- Ideation Gate: APPROVE (Coach + Architekt)
- Next: K1/K2 in Phase 2 schneiden
md
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/examples/example-backlog-slice.md
# Beispiel: Backlog-Slice

## Titel
Progressives Profiling im Onboarding

## Zweck/Nutzen
Reduktion Abbrüche um 10 pp durch gestufte Dateneingabe.

## Beschreibung
Statt 12 Feldern initial nur E‑Mail + Passwort, restliche Felder kontextuell.

## Abhängigkeiten
Tracking-Ereignisse, Datenschutzprüfung.

## DoD
A/B‑Test aktiv; Konfidenz ≥ 90 %; kein Anstieg von Support‑Tickets.

## Metriken/KPIs
Primary: Conversion Onboarding; Secondary: Ticket‑Quote.

## Schätzung
JS: 5; Effort: 2 PW

## Hinweise aus KI-Analysen
Edge‑Cases markiert: Passwort‑Reset‑Flow, Mobile‑Keyboard.
csv
Code kopieren
# path: ki-coaching-zur-skill-uebernahme/assets/examples/example-prioritization-sheet.csv
id,title,bv,tc,rr,js,reach,impact,confidence,effort
K1,Progressives Profiling,8,6,4,5,5000,2,0.8,2
K2,Trust Badges Checkout,6,7,3,3,12000,1,0.7,1
K3,Help-Center Revamp,5,4,2,8,8000,0.5,0.9,3
3) OPTIONAL: Bash‑Installer (Rekonstruktion lokal)
Optional. Der folgende Einzeiler erzeugt den Ordnerbaum; Inhalte bitte aus den obigen Codeblöcken speichern.

bash
Code kopieren
mkdir -p ki-coaching-zur-skill-uebernahme/{references,scripts,assets/templates,assets/examples}
(Alle Datei‑Inhalte stehen vollständig oben bereit und können 1:1 gespeichert werden.)

4) Packaging‑Hinweis & Quick‑Validation
Schneller Check (lokal):

bash
Code kopieren
python quick_validate.py ki-coaching-zur-skill-uebernahme
ZIP erzeugen (lokal):

bash
Code kopieren
python package_skill.py ki-coaching-zur-skill-uebernahme ./dist
# Alternativ:
(cd ki-coaching-zur-skill-uebernahme && zip -r ../ki-coaching-zur-skill-uebernahme.zip .)
Hinweise zur Anwendung im Projekt
Die Mermaid‑State‑Machine (references/state-machine.mmd) visualisiert die Phasen und Schleifen (Iterate Relentlessly).

Review Gates sind harte Stopps. Ohne gültigen JSON‑Record (Schema siehe Template) ist der Phasenwechsel nicht zulässig.

Guarded Autonomy bedeutet: KI darf inspirieren, aber entscheidet nie. Das Team trägt die Verantwortung, der Coach sichert Struktur & Klarheit.

Die Rollenrotation (Script) erzwingt Perspektivwechsel und beugt kognitiver Stagnation vor.





ENTWICKLERMODUS



Umfassendes Nachdenken



ChatGPT kann Fehler machen. OpenAI verwendet keine Daten aus dem Arbeitsbereich DYAI - design your augmented