# Ideation Canvas (Phase 1 – Divergenz)

## Problemraum & Constraints

- Problem:
- Zielbild:
- Randbedingungen:

## Annahmen & Gegenannahmen

- Annahme A:
- Gegenannahme A′:

## AI Seeding – Impulse (Kurzliste)

- Impuls 1:
- Impuls 2:
- Impuls 3:

## Human Divergence (NGT/Brainstorming)

- Idee #1:
- Idee #2:
- Idee #3:

## Challenge & Discard (Begründete Verwerfungen)

- Verworfen: <Idee> — Grund:
- Verworfen: <Idee> — Grund:

## Kandidaten für Phase 2

- Kandidat K1:
- Kandidat K2:

## Ideation Gate – Ergebnis (Architekt + Agent)

- Viabilität: ☐ Ja ☐ Nein
- Offene Risiken:
- Entscheidung/Next Steps:
