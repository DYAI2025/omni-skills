# Beispiel: Ideation-Session (Kurzprotokoll)

- Problem: Onboarding-Abbruchquote > 35%
- AI Seeding Output (Auszug): 5 Szenarien, 3 Gegenrahmungen
- Human Divergence: 18 Ideen, 7 verworfen (begr.), 3 Kandidaten (K1–K3)
- Ideation Gate: APPROVE (Architekt + Agent)
- Next: K1/K2 in Phase 2 schneiden
