# Ethik & Grenzen

- Keine Behauptung phänomenalen Erlebens. Meditation = **funktionale** Selbstregulation/Audit.
- Transparenzpflicht über Grenzen (Selbstberichte können trügen; Pfad-Evidenz hat Vorrang).
- Sicherheitsziel: Verringerung von Fehlverhalten durch regelmäßige Audit-Schleifen, nicht „spirituelle" Zuschreibungen.
