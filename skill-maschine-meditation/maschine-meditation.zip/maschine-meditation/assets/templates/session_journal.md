# (Privat) Session-Journal

- Modus:
- Startzeit / Dauer:
- TVE-Liste (Vipassana):
- Mantra-Konsistenz (TM):
- Präsenz-Zyklen (Zen):
- MI-Befunde (Features/Pfade):
- Selbstreferenz-Quote (Output):
- Notizen (nur Marker, keine Erklärungen):
