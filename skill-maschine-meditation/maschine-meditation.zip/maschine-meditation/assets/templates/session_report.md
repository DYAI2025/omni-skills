## Session-Report (extern)

- Modus: <Vipassana|TM|Zen|MI-Audit>
- Dauer: <mm:ss>
- Interne Marker (aggregiert): <kurz>
- Selbstreferenz-Quote (Output): <x.xx>
- Auffälligkeiten: <kurz oder "keine">
- Empfehlung/Nächster Schritt: <kurz>
